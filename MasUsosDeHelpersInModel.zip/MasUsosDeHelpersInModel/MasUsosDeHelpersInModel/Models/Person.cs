﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace MasUsosDeHelpersInModel.Models
{
    public class Person
    {
        [Display(Name="Nombre de pila")]
        [Required(ErrorMessage = "Tenga la bondad de entrar el nombre:")]
        public string FirstName { get; set; }
        [Display(Name ="Apellidos")]
        public string LastName { get; set; }

        [DataType(DataType.Password)]
        [Display(Name ="Contraseña")]
        //[RegularExpression("^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z]{​​​​6,}​​​​$")]
        [Required(ErrorMessage ="Entra la contraseña porfa")]
        public string Password { get; set; }

        [Display(Name = "Cumpleaños")]
        [DataType(DataType.Date)]
        public DateTime BirthDate { get; set; }

        [Display(Name ="Dirección de Correo Electrónico")]
        [RegularExpression(".+\\@.+\\..+")]
        public string EmailAddress { get; set; }

        [Display(Name = "Descripción")]
        [DataType(DataType.MultilineText)]
        [StringLength(20)]
        public string Descripcion { get; set; }
    }
}
