﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MasUsosDeHelpersInModel.Models;

namespace MasUsosDeHelpersInModel.Controllers
{
    public class PersonController : Controller
    {
        [Route("Person/GetDetails")]
        [HttpGet]
        public IActionResult GetDetails()
        {
            return View();
        }
        [Route("Person/GetDetails")]
        [HttpPost]
        public IActionResult GetDetails(Person person)
        {
            if (ModelState.IsValid)
                return View("ShowDetails", person);
            else
                return View();

        }

    }
}
