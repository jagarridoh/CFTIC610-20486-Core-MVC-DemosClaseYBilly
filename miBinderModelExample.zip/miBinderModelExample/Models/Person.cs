﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace miBinderModelExample.Models
{
    public class Person
    {
        [Display(Name="Nombre de pila")]
        public string FirstName { get; set; }
        [Display(Name ="Apellidos")]
        public string LastName { get; set; }

        [DataType(DataType.Password)]
        [Display(Name ="Contraseña")]
        public string Password { get; set; }

        [Display(Name = "Cumpleaños")]
        [DataType(DataType.Date)]
        public DateTime BirthDate { get; set; }

        [Display(Name ="Dirección de Correo Electrónico")]
        public string EmailAddress { get; set; }

        [Display(Name = "Descripción")]
        [DataType(DataType.MultilineText)]
        public string Descripcion { get; set; }
    }
}
